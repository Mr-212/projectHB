<?php

namespace App\Http\Livewire;

use Livewire\Component;

class HouseDropout extends Component
{
    public function render()
    {
        return view('livewire.house-dropout')->extends('layouts.app');
    }
}
