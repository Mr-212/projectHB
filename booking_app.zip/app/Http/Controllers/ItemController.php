<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ItemController extends Controller
{
    //

//    public function outstanding_before_dd(){
//        return view('item.outstanding_before_dd');
//    }
}
